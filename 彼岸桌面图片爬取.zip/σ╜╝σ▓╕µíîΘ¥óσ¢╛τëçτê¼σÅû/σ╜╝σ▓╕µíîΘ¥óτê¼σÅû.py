import requests
from urllib import request
from lxml import etree
import time
headers={
'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4147.125 Safari/537.36'
}


def get_page(url):
    response=requests.get(url,headers=headers)
    text=response.text
    html=etree.HTML(text)
    img_src=html.xpath('//div[@class="list"]//li/a/img/@src')
    for i in img_src:
        title=i.split("/")[-1]
        request.urlretrieve(i,"photo/"+title)

if __name__ == '__main__':
    for i in range(2,100):
        time.sleep(1)
        url = "http://www.netbian.com/index_{}.htm".format(i)
        print("正在爬取第{}页".format(i))
        get_page(url)


